import React from "react";

export default function App() {
  return (
    <div style={{fontFamily:"Arial", background:"#0b1f14", color:"white", minHeight:"100vh", padding:"20px"}}>

      <div style={{position:"fixed", bottom:20, right:20}}>
        <a href="tel:12294541293">
          <button style={{padding:"15px 20px", borderRadius:30, background:"#22c55e", color:"white", border:"none"}}>
            📞 Call Now
          </button>
        </a>
      </div>

      <header style={{textAlign:"center", padding:"60px 20px"}}>
        <h1 style={{fontSize:42}}>Henry Stump Grinding, LLC</h1>
        <p>5-Star Stump Grinding & Tree Removal in Moultrie, GA</p>
        <a href="tel:12294541293">
          <button style={{marginTop:20, padding:"15px 25px", background:"#16a34a", color:"white", border:"none", borderRadius:10}}>
            Call (229) 454-1293
          </button>
        </a>
      </header>

      <section style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:20}}>
        {["Stump Grinding","Tree Removal","Root Removal","Storm Cleanup"].map((s,i)=>(
          <div key={i} style={{background:"#14532d", padding:20, borderRadius:12}}>
            <h3>{s}</h3>
            <p>Fast, reliable {s.toLowerCase()} service.</p>
          </div>
        ))}
      </section>

      <section style={{marginTop:40, textAlign:"center"}}>
        <h2>Why Choose Us</h2>
        <ul style={{listStyle:"none"}}>
          <li>⭐ 5-Star Local Reputation</li>
          <li>⚡ Fast Response</li>
          <li>💵 Fair Pricing</li>
          <li>🧹 Clean Work</li>
        </ul>
      </section>

      <footer style={{textAlign:"center", marginTop:50, opacity:0.7}}>
        © {new Date().getFullYear()} Henry Stump Grinding, LLC
      </footer>
    </div>
  );
}
